x---------------------------------------x
| Minecraft: Legend of Zelda Map (BETA) |
|   Created by Palstar, Jan 18th 2011   |
x---------------------------------------x

This is a first (beta) version of the Legend of Zelda Map I created.

If you have any feedback, please post it here:
http://www.minecraftforum.net/viewtopic.php?f=25&t=128981

Enjoy!

-- Palstar
